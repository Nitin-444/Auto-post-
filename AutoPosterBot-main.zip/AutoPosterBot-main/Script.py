class script(object):
    START_TXT = """<b>👋 Hello {}, <i>{}</i>

I am a powerful Auto Poster Bot built to simplify your content sharing process.

🚀 Features:
• Auto post to multiple channels
• Custom captions & formatting
• Magnet / Torrent support
• Seamless file streaming

🔧 Just add me to your channel and let me handle the rest!</b>
"""

    RESTART_TXT = """<b>🔄 Bot Restarted!</b>

<b>📅 Date:</b> <code>{}</code>  
<b>⏰ Time:</b> <code>{}</code>  
<b>🌐 Timezone:</b> <code>Asia/Kolkata</code>  
<b>🛠️ Build Status:</b> <code>v2.7.1 [Stable]</code>"""
  
    LOGO = """
   ___  __  __  ___          ___ _    ___  _   _ ___  
  / _ \|  \/  |/ __| __ __  / __| |  / _ \| | | |   \ 
 | (_) | |\/| | (_ | \ \ / | (__| |_| (_) | |_| | |) |
  \___/|_|  |_|\___| /_\_\  \___|____\___/ \___/|___/ """
