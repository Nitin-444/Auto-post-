import re
import pytz
import time
import base64
import aiohttp
from pyrogram import Client
from datetime import datetime
from typing import Any, Optional
from pyrogram.types import Message
from pyrogram.file_id import FileId
from pyrogram.raw.types.messages import Messages
from info import TMDB_API_KEY, TMDB_BASE_URL, TMDB_IMAGE_BASE_URL

################ F2L CODE #####################

StartTime = time.time()
__version__ = 1.1

class InvalidHash(Exception):
    message = "Invalid hash"

class FIleNotFound(Exception):
    message = "File not found"
    
async def parse_file_id(message: "Message") -> Optional[FileId]:
    media = get_media_from_message(message)
    if media:
        return FileId.decode(media.file_id)

async def parse_file_unique_id(message: "Messages") -> Optional[str]:
    media = get_media_from_message(message)
    if media:
        return media.file_unique_id

async def get_file_ids(client: Client, chat_id: int, id: int) -> Optional[FileId]:
    message = await client.get_messages(chat_id, id)
    if message.empty:
        raise FIleNotFound
    media = get_media_from_message(message)
    file_unique_id = await parse_file_unique_id(message)
    file_id = await parse_file_id(message)
    setattr(file_id, "file_size", getattr(media, "file_size", 0))
    setattr(file_id, "mime_type", getattr(media, "mime_type", ""))
    setattr(file_id, "file_name", getattr(media, "file_name", ""))
    setattr(file_id, "unique_id", file_unique_id)
    return file_id

def get_media_from_message(message: "Message") -> Any:
    media_types = (
        "audio",
        "document",
        "photo",
        "sticker",
        "animation",
        "video",
        "voice",
        "video_note",
    )
    for attr in media_types:
        media = getattr(message, attr, None)
        if media:
            return media

def get_hash(media_msg: Message) -> str:
    media = get_media_from_message(media_msg)
    return getattr(media, "file_unique_id", "")[:6]

def get_name(media_msg: Message) -> str:
    media = get_media_from_message(media_msg)
    return getattr(media, 'file_name', "")

def get_media_file_size(m):
    media = get_media_from_message(m)
    return getattr(media, "file_size", 0)
    
def humanbytes(size):
    if not size:
        return ""
    power = 2**10
    n = 0
    Dic_powerN = {0: ' ', 1: 'K', 2: 'M', 3: 'G', 4: 'T'}
    while size > power:
        size /= power
        n += 1
    return str(round(size, 2)) + " " + Dic_powerN[n] + 'B'

def get_readable_time(seconds: int) -> str:
    count = 0
    readable_time = ""
    time_list = []
    time_suffix_list = ["s", "m", "h", " days"]
    while count < 4:
        count += 1
        if count < 3:
            remainder, result = divmod(seconds, 60)
        else:
            remainder, result = divmod(seconds, 24)
        if seconds == 0 and remainder == 0:
            break
        time_list.append(int(result))
        seconds = int(remainder)
    for x in range(len(time_list)):
        time_list[x] = str(time_list[x]) + time_suffix_list[x]
    if len(time_list) == 4:
        readable_time += time_list.pop() + ", "
    time_list.reverse()
    readable_time += ": ".join(time_list)
    return readable_time

#################################################################################3

LANGUAGE_MAP = {
    "Hindi": "Hindi", "Hin": "Hindi",
    "Bengali": "Bengali", "Ben": "Bengali",
    "English": "English", "Eng": "English",
    "Marathi": "Marathi", "Mar": "Marathi",
    "Tamil": "Tamil", "Tam": "Tamil",
    "Telugu": "Telugu", "Tel": "Telugu",
    "Malayalam": "Malayalam", "Mal": "Malayalam",
    "Kannada": "Kannada", "Kan": "Kannada",
    "Punjabi": "Punjabi", "Pun": "Punjabi",
    "Gujrati": "Gujrati", "Guj": "Gujrati",
    "Korean": "Korean", "Kor": "Korean",
    "Japanese": "Japanese", "Jap": "Japanese",
    "Chinese": "Chinese", "Chi": "Chinese", "Mandarin": "Chinese", "Man": "Chinese",
    "Spanish": "Spanish", "Spa": "Spanish",
    "French": "French", "Fre": "French",
    "German": "German", "Ger": "German",
    "Russian": "Russian", "Rus": "Russian",
    "Portuguese": "Portuguese", "Por": "Portuguese",
    "Italian": "Italian", "Ita": "Italian",
    "Arabic": "Arabic", "Ara": "Arabic",
    "Turkish": "Turkish", "Tur": "Turkish",
    "Vietnamese": "Vietnamese", "Vie": "Vietnamese",
    "Urdu": "Urdu", "Urd": "Urdu",
    "Thai": "Thai", "Tha": "Thai",
    "Persian": "Persian", "Per": "Persian", "Farsi": "Persian",
    "Dutch": "Dutch", "Dut": "Dutch",
    "Greek": "Greek", "Gre": "Greek",
    "Hebrew": "Hebrew", "Heb": "Hebrew",
    "Indonesian": "Indonesian", "Indo": "Indonesian",
    "Bhojpuri": "Bhojpuri", "Bho": "Bhojpuri",
    "Dual": "Dual", "Multi": "Multi"
}

# temp
class temp(object):
    ME = None
    U_NAME = None
    B_NAME = None

async def encode(string):
    string_bytes = string.encode("ascii")
    base64_bytes = base64.urlsafe_b64encode(string_bytes)
    base64_string = (base64_bytes.decode("ascii")).strip("=")
    return base64_string

async def decode(base64_string):
    base64_string = base64_string.strip("=")
    base64_bytes = (base64_string + "=" * (-len(base64_string) % 4)).encode("ascii")
    string_bytes = base64.urlsafe_b64decode(base64_bytes) 
    string = string_bytes.decode("ascii")
    return string

def get_size(size):
    units = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB"]
    size = float(size)
    i = 0
    while size >= 1024.0 and i < len(units):
        i += 1
        size /= 1024.0
    return "%.2f%s" % (size, units[i])


def get_wish():
    tz = pytz.timezone('Asia/Colombo')
    time = datetime.now(tz)
    hour = time.hour  # Get hour in 24-hour format
    minute = time.minute  # Get minute for precise comparisons
    # Good Morning: 5:00 AM to 11:59 AM
    if 5 <= hour < 12:
        status = "Good Morning 🌞"
    # Good Afternoon: 12:00 PM to 4:59 PM
    elif 12 <= hour < 17:
        status = "Good Afternoon 🌗"
    # Good Evening: 5:00 PM to 8:59 PM
    elif 17 <= hour < 21:
        status = "Good Evening 🌘"
    # Good Night: 9:00 PM to 4:59 AM
    else:  # Covers 9:00 PM to 4:59 AM
        status = "Good Night 🌙"
    return status


def clean_title_for_search(title):
    title = re.sub(r'^(@\w+\s*[-\s]*|TMV\s*[-\s]*|TBL\s*[-\s]*)', '', title, flags=re.IGNORECASE)
    title = re.sub(r'\s*\(.*?\)\s*', '', title)
    title = re.sub(r'\s*\[.*?\]\s*', '', title)
    title = re.sub(r'[\.\-_]+', ' ', title)
    title = re.sub(r'\s+', ' ', title)
    return title.strip()

async def get_movie_poster(title, year=None):
    try:
        async with aiohttp.ClientSession() as session:
            clean_title = clean_title_for_search(title)
            search_url = f"{TMDB_BASE_URL}/search/movie"
            params = {
                'api_key': TMDB_API_KEY,
                'query': clean_title,
                'language': 'en-US',
                'page': 1
            }
            if year and year != "Unknown Year":
                params['year'] = year
            async with session.get(search_url, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    results = data.get('results', [])
                    if results:
                        movie = results[0]
                        poster_path = movie.get('poster_path')
                        if poster_path:
                            poster_url = f"{TMDB_IMAGE_BASE_URL}{poster_path}"
                            return {
                                'poster_url': poster_url,
                                'title': movie.get('title', title),
                                'release_date': movie.get('release_date', ''),
                                'overview': movie.get('overview', ''),
                                'vote_average': movie.get('vote_average', 0),
                                'tmdb_id': movie.get('id')
                            }
    except Exception as e:
        print(f"Error searching movie: {e}")
    return None

async def get_tv_series_poster(title, year=None):
    try:
        async with aiohttp.ClientSession() as session:
            clean_title = clean_title_for_search(title)
            search_url = f"{TMDB_BASE_URL}/search/tv"
            params = {
                'api_key': TMDB_API_KEY,
                'query': clean_title,
                'language': 'en-US',
                'page': 1
            }
            if year and year != "Unknown Year":
                params['first_air_date_year'] = year
            async with session.get(search_url, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    results = data.get('results', [])
                    if results:
                        tv_show = results[0]
                        poster_path = tv_show.get('poster_path')
                        if poster_path:
                            poster_url = f"{TMDB_IMAGE_BASE_URL}{poster_path}"
                            return {
                                'poster_url': poster_url,
                                'title': tv_show.get('name', title),
                                'first_air_date': tv_show.get('first_air_date', ''),
                                'overview': tv_show.get('overview', ''),
                                'vote_average': tv_show.get('vote_average', 0),
                                'tmdb_id': tv_show.get('id')
                            }
    except Exception as e:
        print(f"Error searching TV series: {e}")
    return None

def is_web_series_file(text):
    if not text:
        return False
    pattern = r'S\d{1,2}\s*[\.\- ]*(?:E|EP)\s*\d{1,2}'
    return bool(re.search(pattern, text, re.IGNORECASE))

def extract_season_episode(text):
    pattern = r'S(\d{1,2})\s*[\.\- ]*(?:E|EP)\s*(\d{1,2})'
    match = re.search(pattern, text, re.IGNORECASE)
    if match:
        return int(match.group(1)), int(match.group(2))
    return None, None

def extract_series_title(text):
    title = re.sub(r'S\d{1,2}\s*[\.\- ]*(?:E|EP)\s*\d{1,2}.*$', '', text, flags=re.IGNORECASE).strip()
    title = re.sub(r'[\[\(]\d{4}[\]\)]', '', title).strip()
    title = re.sub(r'^(@\w+\s*[-\s]*|TMV\s*[-\s]*|TBL\s*[-\s]*)', '', title, flags=re.IGNORECASE)
    title = re.sub(r'[\.\-]{2,}', ' ', title)
    return title.strip(' -.')

def extract_quality(text):
    if not text:
        return "Unknown Quality"
    quality_matches = re.findall(r'(?:\d{3,4}p)', text, re.IGNORECASE)
    # Remove duplicates
    seen = set()
    unique_qualities = [x.lower() for x in quality_matches if not (x.lower() in seen or seen.add(x.lower()))]
    unique_qualities.sort(key=lambda x: int(x[:-1]))
    return ', '.join(unique_qualities) if unique_qualities else "Unknown Quality"

def is_multi_language_file(caption):
    multi_lang_pattern = r'\[[^\]]*\+[^\]]*\]'
    return bool(re.search(multi_lang_pattern, caption, re.IGNORECASE))

def extract_languages_from_caption(caption):
    languages = set()
    # Only process if it's a multi-language file
    if not is_multi_language_file(caption):
        # For single language files, use existing LANGUAGE_MAP method
        file_languages = [
            full_name for abbr, full_name in LANGUAGE_MAP.items() 
            if re.search(rf'\b{abbr}\b', caption, re.IGNORECASE)
        ]
        return file_languages if file_languages else ["Unknown Language"]
    # Comprehensive language mapping for multi-language files
    language_mapping = {
        'eng': 'English', 'english': 'English', 'en': 'English',
        'hin': 'Hindi', 'hindi': 'Hindi', 'hi': 'Hindi',
        'tam': 'Tamil', 'tamil': 'Tamil', 'ta': 'Tamil',
        'tel': 'Telugu', 'telugu': 'Telugu', 'te': 'Telugu',
        'mal': 'Malayalam', 'malayalam': 'Malayalam', 'ml': 'Malayalam',
        'kan': 'Kannada', 'kannada': 'Kannada', 'kn': 'Kannada',
        'ben': 'Bengali', 'bengali': 'Bengali', 'bn': 'Bengali', 'bangla': 'Bengali',
        'guj': 'Gujarati', 'gujarati': 'Gujarati', 'gu': 'Gujarati',
        'mar': 'Marathi', 'marathi': 'Marathi', 'mr': 'Marathi',
        'pun': 'Punjabi', 'punjabi': 'Punjabi', 'pa': 'Punjabi',
        'urd': 'Urdu', 'urdu': 'Urdu', 'ur': 'Urdu',
        'spa': 'Spanish', 'spanish': 'Spanish', 'es': 'Spanish',
        'fre': 'French', 'french': 'French', 'fr': 'French', 'fra': 'French',
        'ger': 'German', 'german': 'German', 'de': 'German', 'deu': 'German',
        'ita': 'Italian', 'italian': 'Italian', 'it': 'Italian',
        'por': 'Portuguese', 'portuguese': 'Portuguese', 'pt': 'Portuguese',
        'rus': 'Russian', 'russian': 'Russian', 'ru': 'Russian',
        'chi': 'Chinese', 'chinese': 'Chinese', 'zh': 'Chinese', 'mandarin': 'Chinese',
        'jpn': 'Japanese', 'japanese': 'Japanese', 'ja': 'Japanese',
        'kor': 'Korean', 'korean': 'Korean', 'ko': 'Korean',
        'ara': 'Arabic', 'arabic': 'Arabic', 'ar': 'Arabic'
    }
    # Find languages in brackets with + symbol
    bracket_pattern = r'\[([^\]]*\+[^\]]*)\]'
    bracket_matches = re.findall(bracket_pattern, caption, re.IGNORECASE)
    for match in bracket_matches:
        # Split by + and clean up
        parts = re.split(r'\s*\+\s*', match)
        for part in parts:
            part = part.strip().lower()
            if part in language_mapping:
                languages.add(language_mapping[part])
    return sorted(list(languages)) if languages else ["Unknown Language"]
