import pytz
import asyncio
from aiohttp import web
from update import temp
from Script import script
from pyrogram import types
from plugins import omg_server
from pyrogram import Client, idle
from datetime import date, datetime
from web import Bot
from web.clients import initialize_clients
from web.utils.keepalive import ping_server
from typing import Union, Optional, AsyncGenerator
from info import SESSION, API_ID, API_HASH, BOT_TOKEN, LOG_CHANNEL, PORT, ON_HEROKU

Bot.start()
loop = asyncio.get_event_loop()

async def OMGxStart():
    bot_info = await Bot.get_me()
    Bot.username = bot_info.username
    await initialize_clients()
    if ON_HEROKU:
        asyncio.create_task(ping_server())
    me = await Bot.get_me()
    temp.ME = me.id
    temp.U_NAME = me.username
    temp.B_NAME = me.first_name
    Bot.username = '@' + me.username
    print(f"{me.first_name} 🐼 started on {me.username}")
    print(script.LOGO)
    tz = pytz.timezone('Asia/Kolkata')
    today = date.today()
    now = datetime.now(tz)
    time = now.strftime("%H:%M:%S %p")
    await Bot.send_message(chat_id=LOG_CHANNEL, text=script.RESTART_TXT.format(today, time))
    app = web.AppRunner(await omg_server())
    await app.setup()
    bind_address = "0.0.0.0"
    await web.TCPSite(app, bind_address, PORT).start()
    await idle()

if __name__ == '__main__':
    try:
        loop.run_until_complete(OMGxStart())
        print('Bot Starting.......🚀')
    except KeyboardInterrupt:
        print('Bot Stopped........☹️')
