import random
import asyncio
from Script import script
from pyrogram import Client, filters, enums
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from info import START_PICS, LOG_CHANNEL
from update import get_wish, decode

@Client.on_message(filters.command('start'))
async def start(client, message):
    if len(message.command) == 1:
        buttons = [[
            InlineKeyboardButton('📚 Help 📚', callback_data='help'),
            InlineKeyboardButton('⚡ About ⚡', callback_data='about')
        ],[
            InlineKeyboardButton('💸 Donate 💸', callback_data='donate')
        ]]
        reply_markup = InlineKeyboardMarkup(buttons)
        await message.reply_photo(
            photo=random.choice(START_PICS),
            caption=script.START_TXT.format(message.from_user.mention, get_wish()),
            reply_markup=reply_markup,
            parse_mode=enums.ParseMode.HTML
        )
        return
    base64_string = message.command[1]
    decoded_string = await decode(base64_string)
    command, converted_id = decoded_string.split('-')
    if command == 'get':
        message_id = int(converted_id) // abs(LOG_CHANNEL)
        file = await client.get_messages(LOG_CHANNEL, message_id)
        if file.document:
            media = file.document
            send_func = message.reply_document
        elif file.video:
            media = file.video
            send_func = message.reply_video
        else:
            await message.reply_text("<b>The message does not contain a document or video.</b>")
            return
        caption = f"<b>{file.caption}</b>" if file.caption else "<b>Here is your file.</b>"
        sent_file = await send_func(media.file_id, caption=caption, parse_mode=enums.ParseMode.HTML)
        notice = await sent_file.reply_text("<b>This file will auto-delete in <u>10 minutes</u> due to copyright. Please save/forward it to avoid loss ⏰</b>", quote=True)
        await asyncio.sleep(300)
        await sent_file.delete()
        await notice.delete()


