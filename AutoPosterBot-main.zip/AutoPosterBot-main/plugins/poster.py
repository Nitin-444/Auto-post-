"""import re
from database.userdb import db
from pyrogram import Client, filters
from urllib.parse import quote_plus
from info import LOG_CHANNEL, POSTER_CHANNEL, URL
from update import get_name, get_hash, encode, temp, get_size, get_movie_poster, get_tv_series_poster, is_web_series_file, extract_season_episode, extract_series_title, is_multi_language_file, extract_languages_from_caption, extract_quality, LANGUAGE_MAP

@Client.on_message(filters.channel & (filters.document | filters.video) & filters.chat(LOG_CHANNEL))  
async def post(client, message):  
    try:  
        if message.chat.id == LOG_CHANNEL and message.sender_chat and message.sender_chat.id == (await client.get_me()).id:  
            return  
        if message.chat.id != LOG_CHANNEL:  
            post_message = await message.copy(chat_id=LOG_CHANNEL, disable_notification=True)  
        else:  
            post_message = message  
      
        converted_id = post_message.id * abs(LOG_CHANNEL)  
        base64_string = await encode(f"get-{converted_id}")  
        bot_username = temp.U_NAME  
        link = f"https://t.me/{bot_username}?start={base64_string}"

        
        
        # Media -- File Name And File Caption 
        media = message.document or message.video  
        file_name = media.file_name if media and media.file_name else "File"  
        file_caption = message.caption if message.caption else ""

        # Web Series 
        if is_web_series_file(file_name) or is_web_series_file(file_caption):
            print(f"Processing web series file: {file_caption}")
            
            # Series information
            season_num, episode_num = extract_season_episode(file_caption or file_name)
            series_title = extract_series_title(file_name)
            quality = extract_quality(file_caption)
            languages = extract_languages_from_caption(file_caption)
            
            # Extract year from caption
            year_match = re.search(r'(\d{4})', file_caption)
            year = year_match.group(1) if year_match else None
            
            # Get file size
            file_size = get_size(media.file_size)
            file_size_bytes = media.file_size
            print(f"Series: {series_title}, Season: {season_num}, Episode: {episode_num}, Quality: {quality}")
            
            # Create file info
            file_info = {
                'file_name': file_name,
                'caption': file_caption,
                'size': file_size,
                'size_bytes': file_size_bytes,
                'link': link,
                'quality': quality,
                'languages': languages,
                'season': season_num,
                'episode': episode_num
            }
            
            # Create series key (group by series and season)
            series_key = f"WEBSERIES_{series_title}_S{season_num:02d}"
            
            # Check if series already exists
            existing_series = db.get_movie(series_key)
            
            if existing_series:
                print(f"Series exists, adding episode {episode_num}")
                
                # Check for duplicate
                duplicate_found = False
                for existing_file in existing_series.get('files', []):
                    if (existing_file.get('episode') == episode_num and 
                        existing_file.get('quality') == quality):
                        print(f"Duplicate found: S{season_num:02d}E{episode_num:02d} {quality}")
                        duplicate_found = True
                        break
                
                if duplicate_found:
                    return
                
                # Add new file
                db.add_file_to_movie(series_key, file_info)
                updated_series = db.get_movie(series_key)
                
                # Process all files and group by episode
                episodes = {}
                all_languages = set()
                all_qualities = set()
                
                for file_data in updated_series['files']:
                    ep_num = file_data.get('episode', 1)
                    file_quality = file_data.get('quality', 'Unknown Quality')
                    
                    if ep_num not in episodes:
                        episodes[ep_num] = {}
                    
                    episodes[ep_num][file_quality] = file_data['link']
                    
                    # Collect all languages and qualities
                    if file_data.get('languages'):
                        all_languages.update(file_data['languages'])
                    
                    if file_quality != 'Unknown Quality':
                        all_qualities.add(file_quality)
                
                # Build episode list
                episode_lines = []
                for ep_num in sorted(episodes.keys()):
                    quality_links = []
                    for qual in sorted(episodes[ep_num].keys()):
                        quality_links.append(f"<a href='{episodes[ep_num][qual]}'>{qual}</a>")
                    
                    episode_lines.append(f"<b>📦 EP{ep_num:02d} : {' | '.join(quality_links)}</b>")
                
                # Create updated caption
                language_text = ', '.join(sorted(all_languages)) if all_languages else "Unknown Language"
                quality_text = ', '.join(sorted(all_qualities)) if all_qualities else "Unknown Quality"
                
                updated_caption = f"<b>🎬 Title : {series_title}</b>\n"
                updated_caption += f"<b>📂 Season: {season_num}</b>\n"
                updated_caption += f"<b>🔊 Audio : {language_text}</b>\n"
                updated_caption += f"<b>💿 Quality : {quality_text}</b>\n\n"
                updated_caption += "\n".join(episode_lines)
                
                # Update existing message
                try:
                    await client.edit_message_text(
                        chat_id=POSTER_CHANNEL,
                        message_id=existing_series['message_id'],
                        text=updated_caption
                    )
                    print(f"Updated web series post: {series_title} S{season_num:02d}")
                except Exception as e:
                    print(f"Error updating web series post: {e}")
            
            else:
                print(f"Creating new series post: {series_title}")
                
                # Get TMDB poster for TV series
                poster_info = await get_tv_series_poster(series_title, year)
                
                # Create new series post
                language_text = ', '.join(languages)
                
                caption = f"<b>🎬 Title : {series_title}</b>\n"
                caption += f"<b>📂 Season: {season_num}</b>\n"
                caption += f"<b>🔊 Audio : {language_text}</b>\n"
                caption += f"<b>💿 Quality : {quality}</b>\n\n"
                caption += f"<b>📦 EP{episode_num:02d} : <a href='{link}'>{quality}</a></b>"
                
                # Send new message with or without photo
                if poster_info and poster_info.get('poster_url'):
                    try:
                        sent_message = await client.send_photo(
                            chat_id=POSTER_CHANNEL,
                            photo=poster_info['poster_url'],
                            caption=caption
                        )
                        print(f"Sent web series with poster: {series_title}")
                    except Exception as photo_error:
                        print(f"Error sending photo, sending text only: {photo_error}")
                        sent_message = await client.send_message(
                            chat_id=POSTER_CHANNEL,
                            text=caption
                        )
                else:
                    sent_message = await client.send_message(
                        chat_id=POSTER_CHANNEL,
                        text=caption
                    )
                sticker = "CAACAgUAAxkBAAIIVmg9KCOeWPgAAWFvKybPiYtxxwp8FQACbg8AAh_ziFRuzlbQ4ZKcNh4E"
                await client.send_sticker(
                    chat_id=POSTER_CHANNEL,
                    sticker=sticker
                )
                
                # Save to database (FIXED: Removed await)
                series_data = {
                    'title': series_title,
                    'season': season_num,
                    'year': year,
                    'message_id': sent_message.id,
                    'files': [file_info],
                    'type': 'webseries',
                    'poster_info': poster_info
                }
                
                db.save_movie(series_key, series_data)
                print(f"Created new web series post: {series_title} S{season_num:02d}")
        else:
            # Movie Processing 
            print(f"Processing movie file: {file_name}")
            file_caption = message.caption.split('\n')[0] if message.caption else ""
      
            # Movie Title
            title_text = file_caption if file_caption else file_name
            movie_title = re.sub(r'^(@\w+\s*[-\s]*|TMV\s*[-\s]*|TBL\s*[-\s]*)', '', title_text, flags=re.IGNORECASE)
            movie_title = re.split(r'\s*\(?\d{4}\)?|\s+(?:BR-?Rip|WEB-?Rip|HD|720p|1080p|x264|x265)', movie_title)[0]
            movie_title = movie_title.strip(' -.')
            
            # Movie Year
            year_match = re.search(r'(\d{4})', file_caption)
            year = year_match.group(1) if year_match else "Unknown Year"
            
            # Movie Quality
            quality_matches = re.findall(r'(?:\d{3,4}p|HDRip|4K|PreDVD|WEB-DL|BDRip)', file_caption, re.IGNORECASE)
            current_quality = ', '.join(quality_matches) if quality_matches else "Unknown Quality"
            
            # Extract languages using improved method
            file_languages = extract_languages_from_caption(file_caption)
            
            # File Size
            if message.document:
                file_size = get_size(message.document.file_size)
                file_size_bytes = message.document.file_size
            elif message.video:  
                file_size = get_size(message.video.file_size)
                file_size_bytes = message.video.file_size
            else:  
                file_size = "N/A"
                file_size_bytes = 0

            log_msg = await message.forward(chat_id=LOG_CHANNEL)
            stream = f"{URL}watch/{str(log_msg.id)}/{quote_plus(get_name(log_msg))}?hash={get_hash(log_msg)}"
            download = f"{URL}{str(log_msg.id)}/{quote_plus(get_name(log_msg))}?hash={get_hash(log_msg)}"
            
            # Create file info
            file_info = {
                'caption': file_caption,
                'size': file_size,
                'size_bytes': file_size_bytes,
                'link': link,
                'stream': stream,
                'download': download,
                'quality': current_quality,
                'languages': file_languages
            }
            
            # Create movie key based on whether it's multi-language or not
            if is_multi_language_file(file_caption):
                # For multi-language files, use only title and year (group together)
                movie_key = f"{movie_title}_{year}"
            else:
                # For single language files, include language in key (separate posts)
                language_text = ', '.join(file_languages)
                movie_key = f"{movie_title}_{year}_{language_text}"
                
            existing_movie = db.get_movie(movie_key)
            
            if existing_movie:
                if db.check_file_exists(movie_key, file_caption):
                    print(f"Duplicate file detected, skipping: {file_caption}")
                    return
                    
                # Movie exists, add new file and update post
                db.add_file_to_movie(movie_key, file_info)
                updated_movie = db.get_movie(movie_key)
            
                # Collect all unique languages from all files
                all_languages = set()
                all_qualities = set()
            
                for file_data in updated_movie['files']:
                    if 'languages' in file_data:
                        all_languages.update(file_data['languages'])
                        
                    file_qualities = file_data['quality'].split(', ')
                    all_qualities.update([q.strip() for q in file_qualities if q.strip() != "Unknown Quality"])
                    
                # Create combined language and quality text
                language_text = ', '.join(sorted(all_languages)) if all_languages else "Unknown Language"
                quality_text = ', '.join(sorted(all_qualities)) if all_qualities else "Unknown Quality"
            
                # Sort files by size (smallest to largest)
                sorted_files = sorted(updated_movie['files'], key=lambda x: x['size_bytes'])
            
                # Build file list
                file_list = []
                for file_data in sorted_files:
                    file_list.append(f"<b>{file_data['caption']}</b>\n<b>({file_data['size']}) : <a href='{file_data['stream']}'>Stream</a> | <a href='{file_data['download']}'>Download</a>| <a href='{file_data['link']}'>Get File</a></b>")
                    
                # Create updated caption
                updated_caption = (
                    f"<b>🎬 Title : {movie_title}</b>\n"
                    f"<b>📆 Year : {year}</b>\n"
                    f"<b>🔊 Audio : {language_text}</b>\n"
                    f"<b>💿 Quality : {quality_text}</b>\n\n"
                    + "\n\n".join(file_list)
                )
                
                # Edit existing message
                try:
                    # Check if original message has photo
                    if updated_movie.get('poster_info'):
                        await client.edit_message_caption(
                            chat_id=POSTER_CHANNEL,
                            message_id=existing_movie['message_id'],
                            caption=updated_caption
                        )
                    else:
                        await client.edit_message_text(
                            chat_id=POSTER_CHANNEL,
                            message_id=existing_movie['message_id'],
                            text=updated_caption
                        )
                    print(f"Updated existing post for: {movie_title}")
                    file_sizes = [file_data['size'] for file_data in sorted_files]
                    print(f"Files in size order: {' → '.join(file_sizes)}")
                    print(f"Combined languages: {language_text}")
                except Exception as edit_error:
                    print(f"Error editing message: {edit_error}")
            else:
                # New movie, create new post
                language_text = ', '.join(file_languages)
                caption = (
                    f"<b>🎬 Title : {movie_title}</b>\n"
                    f"<b>📆 Year : {year}</b>\n"
                    f"<b>🔊 Audio : {language_text}</b>\n"
                    f"<b>💿 Quality : {current_quality}</b>\n\n"
                    f"<b>{file_caption}</b>\n"
                    f"<b>({file_size}) : <a href='{stream}'>Stream</a> | <a href='{download}'>Download</a> | <a href='{link}'>Get File</a></b>"
                )
                
                # Get TMDB poster for movie
                poster_info = await get_movie_poster(movie_title, year if year != "Unknown Year" else None)
                
                # Send new message with or without photo
                if poster_info and poster_info.get('poster_url'):
                    try:
                        sent_message = await client.send_photo(
                            chat_id=POSTER_CHANNEL,
                            photo=poster_info['poster_url'],
                            caption=caption
                        )
                        print(f"Sent movie with poster: {movie_title}")
                    except Exception as photo_error:
                        print(f"Error sending photo, sending text only: {photo_error}")
                        sent_message = await client.send_message(
                            chat_id=POSTER_CHANNEL,
                            text=caption
                        )
                else:
                    sent_message = await client.send_message(
                        chat_id=POSTER_CHANNEL,
                        text=caption
                    )
                sticker = "CAACAgUAAxkBAAIIVmg9KCOeWPgAAWFvKybPiYtxxwp8FQACbg8AAh_ziFRuzlbQ4ZKcNh4E"
                await client.send_sticker(
                    chat_id=POSTER_CHANNEL,
                    sticker=sticker
                )
                
                # Save to database (FIXED: Removed await)
                movie_data = {
                    'title': movie_title,
                    'year': year,
                    'message_id': sent_message.id,
                    'files': [file_info],
                    'poster_info': poster_info
                }
                db.save_movie(movie_key, movie_data)
                print(f"Created new post for: {movie_title}")
    except Exception as e:
        print(f"Error in post function: {e}")"""

import re
from database.userdb import db
from pyrogram import Client, filters
from urllib.parse import quote_plus
from info import LOG_CHANNEL, POSTER_CHANNEL, URL
from update import get_name, get_hash, encode, temp, get_size, get_movie_poster, get_tv_series_poster, is_web_series_file, extract_season_episode, extract_series_title, is_multi_language_file, extract_languages_from_caption, extract_quality, LANGUAGE_MAP

@Client.on_message(filters.channel & (filters.document | filters.video) & filters.chat(LOG_CHANNEL))  
async def post(client, message):  
    try:  
        if message.chat.id == LOG_CHANNEL and message.sender_chat and message.sender_chat.id == (await client.get_me()).id:  
            return  
        if message.chat.id != LOG_CHANNEL:  
            post_message = await message.copy(chat_id=LOG_CHANNEL, disable_notification=True)  
        else:  
            post_message = message  
      
        converted_id = post_message.id * abs(LOG_CHANNEL)  
        base64_string = await encode(f"get-{converted_id}")  
        bot_username = temp.U_NAME  
        link = f"https://t.me/{bot_username}?start={base64_string}"

        # Media -- File Name And File Caption 
        media = message.document or message.video  
        file_name = media.file_name if media and media.file_name else "File"  
        file_caption = message.caption if message.caption else ""

        # Web Series 
        if is_web_series_file(file_name) or is_web_series_file(file_caption):
            print(f"Processing web series file: {file_caption}")
            
            # Series information
            season_num, episode_num = extract_season_episode(file_caption or file_name)
            series_title = extract_series_title(file_name)
            quality = extract_quality(file_caption)
            languages = extract_languages_from_caption(file_caption)
            
            # Extract year from caption
            year_match = re.search(r'(\d{4})', file_caption)
            year = year_match.group(1) if year_match else None
            
            # Get file size
            file_size = get_size(media.file_size)
            file_size_bytes = media.file_size
            print(f"Series: {series_title}, Season: {season_num}, Episode: {episode_num}, Quality: {quality}")
            
            # Create file info (without stream/download links for web series)
            file_info = {
                'file_name': file_name,
                'caption': file_caption,
                'size': file_size,
                'size_bytes': file_size_bytes,
                'link': link,
                'quality': quality,
                'languages': languages,
                'season': season_num,
                'episode': episode_num
            }
            
            # Create series key (group by series and season)
            series_key = f"WEBSERIES_{series_title}_S{season_num:02d}"
            
            # Check if series already exists
            existing_series = db.get_movie(series_key)
            
            if existing_series:
                print(f"Series exists, adding episode {episode_num}")
                
                # Check for duplicate
                duplicate_found = False
                for existing_file in existing_series.get('files', []):
                    if (existing_file.get('episode') == episode_num and 
                        existing_file.get('quality') == quality):
                        print(f"Duplicate found: S{season_num:02d}E{episode_num:02d} {quality}")
                        duplicate_found = True
                        break
                
                if duplicate_found:
                    return
                
                # Add new file
                db.add_file_to_movie(series_key, file_info)
                updated_series = db.get_movie(series_key)
                
                # Process all files and group by episode
                episodes = {}
                all_languages = set()
                all_qualities = set()
                
                for file_data in updated_series['files']:
                    ep_num = file_data.get('episode', 1)
                    file_quality = file_data.get('quality', 'Unknown Quality')
                    
                    if ep_num not in episodes:
                        episodes[ep_num] = {}
                    
                    episodes[ep_num][file_quality] = file_data['link']
                    
                    # Collect all languages and qualities
                    if file_data.get('languages'):
                        all_languages.update(file_data['languages'])
                    
                    if file_quality != 'Unknown Quality':
                        all_qualities.add(file_quality)
                
                # Build episode list
                episode_lines = []
                for ep_num in sorted(episodes.keys()):
                    quality_links = []
                    for qual in sorted(episodes[ep_num].keys()):
                        quality_links.append(f"<a href='{episodes[ep_num][qual]}'>{qual}</a>")
                    
                    episode_lines.append(f"<b>📦 EP{ep_num:02d} : {' | '.join(quality_links)}</b>")
                
                # Create updated caption
                language_text = ', '.join(sorted(all_languages)) if all_languages else "Unknown Language"
                quality_text = ', '.join(sorted(all_qualities)) if all_qualities else "Unknown Quality"
                
                updated_caption = f"<b>🎬 Title : {series_title}</b>\n"
                updated_caption += f"<b>📂 Season: {season_num}</b>\n"
                updated_caption += f"<b>🔊 Audio : {language_text}</b>\n"
                updated_caption += f"<b>💿 Quality : {quality_text}</b>\n\n"
                updated_caption += "\n".join(episode_lines)
                
                # Update existing message
                try:
                    await client.edit_message_text(
                        chat_id=POSTER_CHANNEL,
                        message_id=existing_series['message_id'],
                        text=updated_caption
                    )
                    print(f"Updated web series post: {series_title} S{season_num:02d}")
                except Exception as e:
                    print(f"Error updating web series post: {e}")
            
            else:
                print(f"Creating new series post: {series_title}")
                
                # Get TMDB poster for TV series
                poster_info = await get_tv_series_poster(series_title, year)
                
                # Create new series post
                language_text = ', '.join(languages)
                
                caption = f"<b>🎬 Title : {series_title}</b>\n"
                caption += f"<b>📂 Season: {season_num}</b>\n"
                caption += f"<b>🔊 Audio : {language_text}</b>\n"
                caption += f"<b>💿 Quality : {quality}</b>\n\n"
                caption += f"<b>📦 EP{episode_num:02d} : <a href='{link}'>{quality}</a></b>"
                
                # Send new message with or without photo
                if poster_info and poster_info.get('poster_url'):
                    try:
                        sent_message = await client.send_photo(
                            chat_id=POSTER_CHANNEL,
                            photo=poster_info['poster_url'],
                            caption=caption
                        )
                        print(f"Sent web series with poster: {series_title}")
                    except Exception as photo_error:
                        print(f"Error sending photo, sending text only: {photo_error}")
                        sent_message = await client.send_message(
                            chat_id=POSTER_CHANNEL,
                            text=caption
                        )
                else:
                    sent_message = await client.send_message(
                        chat_id=POSTER_CHANNEL,
                        text=caption
                    )
                sticker = "CAACAgUAAxkBAAIIVmg9KCOeWPgAAWFvKybPiYtxxwp8FQACbg8AAh_ziFRuzlbQ4ZKcNh4E"
                await client.send_sticker(
                    chat_id=POSTER_CHANNEL,
                    sticker=sticker
                )
                
                # Save to database
                series_data = {
                    'title': series_title,
                    'season': season_num,
                    'year': year,
                    'message_id': sent_message.id,
                    'files': [file_info],
                    'type': 'webseries',
                    'poster_info': poster_info
                }
                
                db.save_movie(series_key, series_data)
                print(f"Created new web series post: {series_title} S{season_num:02d}")
        else:
            # Movie Processing 
            print(f"Processing movie file: {file_name}")
            file_caption = message.caption.split('\n')[0] if message.caption else ""
            
            # Create stream/download links (only for movies)
            log_msg = await message.forward(chat_id=LOG_CHANNEL)
            stream = f"{URL}watch/{str(log_msg.id)}/{quote_plus(get_name(log_msg))}?hash={get_hash(log_msg)}"
            download = f"{URL}{str(log_msg.id)}/{quote_plus(get_name(log_msg))}?hash={get_hash(log_msg)}"
      
            # Movie Title
            title_text = file_caption if file_caption else file_name
            movie_title = re.sub(r'^(@\w+\s*[-\s]*|TMV\s*[-\s]*|TBL\s*[-\s]*)', '', title_text, flags=re.IGNORECASE)
            movie_title = re.split(r'\s*\(?\d{4}\)?|\s+(?:BR-?Rip|WEB-?Rip|HD|720p|1080p|x264|x265)', movie_title)[0]
            movie_title = movie_title.strip(' -.')
            
            # Movie Year
            year_match = re.search(r'(\d{4})', file_caption)
            year = year_match.group(1) if year_match else "Unknown Year"
            
            # Movie Quality
            quality_matches = re.findall(r'(?:\d{3,4}p|HDRip|4K|PreDVD|WEB-DL|BDRip)', file_caption, re.IGNORECASE)
            current_quality = ', '.join(quality_matches) if quality_matches else "Unknown Quality"
            
            # Extract languages using improved method
            file_languages = extract_languages_from_caption(file_caption)
            
            # File Size
            if message.document:
                file_size = get_size(message.document.file_size)
                file_size_bytes = message.document.file_size
            elif message.video:  
                file_size = get_size(message.video.file_size)
                file_size_bytes = message.video.file_size
            else:  
                file_size = "N/A"
                file_size_bytes = 0

            # Create file info (with stream/download links for movies)
            file_info = {
                'caption': file_caption,
                'size': file_size,
                'size_bytes': file_size_bytes,
                'link': link,
                'stream': stream,
                'download': download,
                'quality': current_quality,
                'languages': file_languages
            }
            
            # Create movie key based on whether it's multi-language or not
            if is_multi_language_file(file_caption):
                # For multi-language files, use only title and year (group together)
                movie_key = f"{movie_title}_{year}"
            else:
                # For single language files, include language in key (separate posts)
                language_text = ', '.join(file_languages)
                movie_key = f"{movie_title}_{year}_{language_text}"
                
            existing_movie = db.get_movie(movie_key)
            
            if existing_movie:
                if db.check_file_exists(movie_key, file_caption):
                    print(f"Duplicate file detected, skipping: {file_caption}")
                    return
                    
                # Movie exists, add new file and update post
                db.add_file_to_movie(movie_key, file_info)
                updated_movie = db.get_movie(movie_key)
            
                # Collect all unique languages from all files
                all_languages = set()
                all_qualities = set()
            
                for file_data in updated_movie['files']:
                    if 'languages' in file_data:
                        all_languages.update(file_data['languages'])
                        
                    file_qualities = file_data['quality'].split(', ')
                    all_qualities.update([q.strip() for q in file_qualities if q.strip() != "Unknown Quality"])
                    
                # Create combined language and quality text
                language_text = ', '.join(sorted(all_languages)) if all_languages else "Unknown Language"
                quality_text = ', '.join(sorted(all_qualities)) if all_qualities else "Unknown Quality"
            
                # Sort files by size (smallest to largest)
                sorted_files = sorted(updated_movie['files'], key=lambda x: x['size_bytes'])
            
                # Build file list
                file_list = []
                for file_data in sorted_files:
                    file_line = f"<b>{file_data['caption']}</b>\n<b>({file_data['size']}) : "
                    if 'stream' in file_data and 'download' in file_data:
                        file_line += f"<a href='{file_data['stream']}'>Stream</a> | <a href='{file_data['download']}'>Download</a> | "
                    file_line += f"<a href='{file_data['link']}'>Get File</a></b>"
                    file_list.append(file_line)
                    
                # Create updated caption
                updated_caption = (
                    f"<b>🎬 Title : {movie_title}</b>\n"
                    f"<b>📆 Year : {year}</b>\n"
                    f"<b>🔊 Audio : {language_text}</b>\n"
                    f"<b>💿 Quality : {quality_text}</b>\n\n"
                    + "\n\n".join(file_list)
                )
                
                # Edit existing message
                try:
                    # Check if original message has photo
                    if updated_movie.get('poster_info'):
                        await client.edit_message_caption(
                            chat_id=POSTER_CHANNEL,
                            message_id=existing_movie['message_id'],
                            caption=updated_caption
                        )
                    else:
                        await client.edit_message_text(
                            chat_id=POSTER_CHANNEL,
                            message_id=existing_movie['message_id'],
                            text=updated_caption
                        )
                    print(f"Updated existing post for: {movie_title}")
                    file_sizes = [file_data['size'] for file_data in sorted_files]
                    print(f"Files in size order: {' → '.join(file_sizes)}")
                    print(f"Combined languages: {language_text}")
                except Exception as edit_error:
                    print(f"Error editing message: {edit_error}")
            else:
                # New movie, create new post
                language_text = ', '.join(file_languages)
                caption = (
                    f"<b>🎬 Title : {movie_title}</b>\n"
                    f"<b>📆 Year : {year}</b>\n"
                    f"<b>🔊 Audio : {language_text}</b>\n"
                    f"<b>💿 Quality : {current_quality}</b>\n\n"
                    f"<b>{file_caption}</b>\n"
                    f"<b>({file_size}) : <a href='{stream}'>Stream</a> | <a href='{download}'>Download</a> | <a href='{link}'>Get File</a></b>"
                )
                
                # Get TMDB poster for movie
                poster_info = await get_movie_poster(movie_title, year if year != "Unknown Year" else None)
                
                # Send new message with or without photo
                if poster_info and poster_info.get('poster_url'):
                    try:
                        sent_message = await client.send_photo(
                            chat_id=POSTER_CHANNEL,
                            photo=poster_info['poster_url'],
                            caption=caption
                        )
                        print(f"Sent movie with poster: {movie_title}")
                    except Exception as photo_error:
                        print(f"Error sending photo, sending text only: {photo_error}")
                        sent_message = await client.send_message(
                            chat_id=POSTER_CHANNEL,
                            text=caption
                        )
                else:
                    sent_message = await client.send_message(
                        chat_id=POSTER_CHANNEL,
                        text=caption
                    )
                sticker = "CAACAgUAAxkBAAIIVmg9KCOeWPgAAWFvKybPiYtxxwp8FQACbg8AAh_ziFRuzlbQ4ZKcNh4E"
                await client.send_sticker(
                    chat_id=POSTER_CHANNEL,
                    sticker=sticker
                )
                
                # Save to database
                movie_data = {
                    'title': movie_title,
                    'year': year,
                    'message_id': sent_message.id,
                    'files': [file_info],
                    'poster_info': poster_info
                }
                db.save_movie(movie_key, movie_data)
                print(f"Created new post for: {movie_title}")
    except Exception as e:
        print(f"Error in post function: {str(e)}")
