from os import getenv, environ

# Bot information
SESSION = getenv("SESSION", "OMGxCLOUD")
API_ID = getenv("API_ID", "10261086")
API_HASH = getenv("API_HASH", "9195dc0591fbdb22b5711bcd1f437dab")
BOT_TOKEN = getenv("BOT_TOKEN", "7463314412:AAF-K0hhRQ3dJ0wYDhHR_JwBeV6XykWLKQs")

# Pics 
START_PICS = (getenv("START_PICS", "https://i.ibb.co/6JBrzqhj/OMGx-Cloud.png")).split()

# Bot Admins & Channels
LOG_CHANNEL = int(getenv('LOG_CHANNEL', "-1002304858881"))
POSTER_CHANNEL = int(getenv('POSTER_CHANNEL', "-1002532771793"))

# Database information
DATABASE_URL = getenv('DATABASE_URL', "mongodb+srv://AutoPosterBot:AutoPosterBot10@cluster0.i24gdnw.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
DATABASE_NAME = getenv("DATABASE_NAME", "AutoPosterBot")
COLLECTION_NAME = getenv("COLLECTION_NAME", 'Files')

# TMDB Configuration
TMDB_API_KEY =  getenv("TMDB_API_KEY", "a1b56d0bbad3184e8f1430802bef2260")
TMDB_BASE_URL =  getenv("TMDB_BASE_URL", "https://api.themoviedb.org/3")
TMDB_IMAGE_BASE_URL =  getenv("TMDB_IMAGE_BASE_URL", "https://image.tmdb.org/t/p/w500")  # High quality poster size

# port information
PORT = int(getenv('PORT', '8080'))

# Online Stream and Download
MULTI_CLIENT = False
SLEEP_THRESHOLD = int(environ.get('SLEEP_THRESHOLD', '60'))
PING_INTERVAL = int(environ.get("PING_INTERVAL", "1200"))  # 20 minutes
if 'DYNO' in environ:
    ON_HEROKU = True
else:
    ON_HEROKU = False
URL = environ.get("URL", "")
